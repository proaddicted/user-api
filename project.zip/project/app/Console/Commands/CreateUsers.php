<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

use Illuminate\Support\Facades\Http; //Include this name space for API Call using Guzzle HTTP Client Package

use App\Models\User; //User Model

use App\Models\UserDetail; //UserDetail Model

use App\Models\UserLocation; //UserLocation Model

use Illuminate\Support\Facades\DB; //Include DB Facade for DB usage

use Exception;

class CreateUsers extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'create:user';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This command creates users by API call from https://randomuser.me/api/ this command will create 5 users from API each time it runs';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        /* Call https://randomuser.me/api/ API N Times Where as N Set in .env file */

        /* We are fetching the https://randomuser.me/api/ API from .env file */

        for ($i=0; $i <= env('NO_USERS_PER_CALL') - 1 ; $i++) { 

            $response = Http::get(env('FETCH_USER_API')); // Calling The API


            if(count($response->json()['results'])) //Check If Output Exists
            {
               
                /* Start Database Transaction */

                DB::beginTransaction();

                try{

                    /* Create User from API Response */

                    $user = User::create([
                        'name'=>trim(implode(' ',$response->json()['results'][0]['name'])), //Create Name From name array in response
                        'email'=>$response->json()['results'][0]['email'],
                        'password'=>$response->json()['results'][0]['login']['sha1']
                    ]);

                    /* Create User Detail from API Response */

                    UserDetail::create([
                        'user_id'=>$user->id,
                        'gender'=>$response->json()['results'][0]['gender']
                    ]);

                    /* Create User Location from API Response */

                    UserLocation::create([
                        'user_id'=>$user->id,
                        'city'=>$response->json()['results'][0]['location']['city'],
                        'country'=>$response->json()['results'][0]['location']['country']
                    ]);

                    /* Commit Transaction if No Error Occured */
                    DB::commit();

                }catch (Exception $ex) {
                    
                    /* Roll Back If Any Exception in Code or Any Error */

                    DB::rollBack();
                   
                }
                
            }

        }


    }
}
