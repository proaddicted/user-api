<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\User; //User Model

use Illuminate\Support\Facades\DB; //Include DB Facade for DB usage

use Illuminate\Support\Collection; 

class UserController extends Controller
{

     /**
     * Public API For Fetch User 
     * @param $request
     * @author Prosanta Mitra <pro.addicted@gmail.com>
     * @copyright Copyright (c) 2024, Prosanta Mitra
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $limit = $request->limit ? $request->limit : 5; //Check If Limit Passed in Parameter or Set Default

        //Fetch users with user_details and user_locations by joining Although we can also use eloquent

        $query = DB::table('users')
        ->join('user_details', 'users.id', '=', 'user_details.user_id')
        ->join('user_locations', 'users.id', '=', 'user_locations.user_id');

    
        /* If column selection passed in params or default */

        if($request->column_select && !empty($request->column_select))
            $query->select(DB::raw($request->column_select));
        else
            $query->select('users.name', 'users.email', 'user_details.gender','user_locations.country','user_locations.city');

        /* Check If Query Param Exists */

        if($request->gender && !empty($request->gender)) //Gender Filter
            $query->where('user_details.gender',$request->gender);     

        if($request->country && !empty($request->country)) //Country Filter
            $query->where('user_locations.country',$request->country);  

        if($request->city && !empty($request->city)) //City Filter
            $query->where('user_locations.city',$request->city); 
        
        $users = $query->take($limit)->get();
        
        return response(['data' => $users,'success'=>true,'message' => 'Data Retrived Successfully'], 200);

    }
}
